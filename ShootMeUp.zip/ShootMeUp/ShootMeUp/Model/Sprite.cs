﻿using ShootMeUp.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShootMeUp.Model
{
    static class Sprite
    {
        public static readonly Bitmap Zombie = Resources.EnemyZombie;
        public static readonly Bitmap Skeleton = Resources.EnemySkeleton;
        public static readonly Bitmap Player = Resources.CharacterPlayer;
        public static readonly Bitmap Pigman = Resources.EnemyZombiePigman;
        public static readonly Bitmap BabyZombie = Resources.EnemyZombie;
        public static readonly Bitmap Blaze = Resources.EnemyBlaze;
        public static readonly Bitmap Arrow = Resources.ProjectileArrow;
        public static readonly Bitmap Fireball = Resources.ProjectileFireball;
    }
}
